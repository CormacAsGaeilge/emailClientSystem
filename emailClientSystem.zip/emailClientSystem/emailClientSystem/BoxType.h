#pragma once
enum BoxType
{
	InboxType,
	OutboxType,
	SentboxType,
	DeletedboxType
};